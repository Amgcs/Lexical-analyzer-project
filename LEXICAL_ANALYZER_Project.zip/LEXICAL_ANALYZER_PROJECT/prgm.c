#include <stdio.h>

//Single-line comment should be ignored

/* Multi-line
   comment should also be ignored */

int main() 
{
    int x_2 = 0b1010;
    float y = 20.53f;
    char c = 'A';
    char d = '\n';

    x = x + y - 5 * 2 / (3 + 1);

    if (x >= 10 && y <= 30) {
        x++;
        y--;
        x += 5;
        y -= 2;
        x *= y;
        y /= 3;
    }

    printf("Hello, World!\n");
    printf("Value of x = %d", x);

    
    a != b;
    a == b;
    a >= b;
    a <= b;
    a && b;
    a || b;

    arr[5] = (x + y) * 2;

    return 0;
}
