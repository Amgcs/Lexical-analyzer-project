#ifndef LEX 
#define LEX


typedef struct keyword      //structure to store keywords(total 32 keywords)
{
    char *key;
}KEYWORD;

int is_keyword(char *buf);  //checks a string is keyword or not
int check_syntax(char ch,FILE *fp,char *erbuff[],int *ersize);  //check syntax ,like opening and closes of braces, multiline comments closed or not
int check_operator(char *buffer);   //checks the operator is valid or not
int check_number(char *buffer);     //checks the operand is valid or not 
int String_termination(char ch,FILE *fp);   // checks string literals terminated or not

#endif