/*
To compile the project      -> make
To run the program          -> ./lexer.exe prgm.c
To clean compiled files     -> make clean
*/


#include<stdio.h>      // Standard I/O functions
#include<string.h>     // String handling functions
#include<ctype.h>      // Character classification functions
#include"lex.h"        // User-defined header functions

int main(int argc,char *argv[])
{
    // Buffer to store error messages
    char *erbuff[50];
    int ersize = 0;

    // Variable to store number of characters checked
    int n_char = 0;

    // File position indicator
    long pos;

    // Temporary variable used during comment handling
    char temp;

    // Flag used for syntax checking (brackets)
    int flag = 0;

    // Buffer to store lexemes (identifiers, numbers, operators, etc.)
    char buffer[50];

    // Counter for buffer indexing
    int count = 0;

    // Display lexer header
    printf("\n==================== LEXICAL ANALYSER ====================\n\n");

    // Check if input file is provided
    if(argv[1] == NULL)
    {
        printf("Provide file!...\n");
        return 0;
    }

    // Open input file in read mode
    FILE *fptr = fopen(argv[1], "r");
    if(fptr == NULL)
    {
        printf("Provide valid file!..\n");
        return 0;
    }

    // Read first character from file
    char ch = fgetc(fptr);

    // Display token table header
    printf("------------------------------------------------------------\n");
    printf("TOKENS              : VALUES\n");
    printf("------------------------------------------------------------\n\n");

    // Main lexical analysis loop
    while(ch != EOF)
    {
        // Ignore spaces and newlines
        if (ch == ' ' || ch == '\n')
        {
            ch = fgetc(fptr);
            continue;
        }

        // Handle preprocessor directives (#include <stdio.h>)
        if(ch == '#')
        {
            // Read until closing '>'
            while((ch = fgetc(fptr)) != '>')
            {
                // Treat < . > as operators for simplicity
                if(ch == '<' || ch == '.' || ch == '>')
                {
                    printf("Operator            : %c\n", ch);
                }
            }
            // Print final '>'
            printf("Operator            : >\n");
            ch = fgetc(fptr);
        }

        // Syntax checking for opening brackets
        if((ch == '{' || ch == '[' || ch == '(') && flag == 0)
        {
            pos = ftell(fptr);
            n_char = check_syntax(ch, fptr, erbuff, &ersize);
            fseek(fptr, pos, SEEK_SET);
            flag = 1;
        }

        // Comment handling
        if(ch == '/')
        {
            temp = ch;
            ch = fgetc(fptr);

            // Single-line comment
            if(ch == '/')
            {
                while((ch = fgetc(fptr)) != '\n');
            }
            // Multi-line comment
            else if(ch == '*')
            {
                char com[3];
                while(1)
                {
                    ch = fgetc(fptr);
                    if(ch == '*')
                    {
                        char next;
                        if((next = fgetc(fptr)) == '/')
                        {
                            com[0] = ch;
                            com[1] = next;
                            com[2] = '\0';
                        }
                        else
                            ungetc(next, fptr);
                    }
                    // Check for comment termination
                    if(!strcmp(com, "*/"))
                    {
                        ch = fgetc(fptr);
                        break;
                    }
                    // Unterminated comment error
                    if(ch == EOF)
                    {
                        printf("Unterminated comment\n");
                        return 0;
                    }
                }
            }
            // Not a comment, revert back
            else
            {
                ungetc(ch, fptr);
                ch = temp;
            }
        }

        // Identifier or keyword handling
        if(isalpha(ch) || ch == '_')
        {
            count = 0;
            while(isalpha(ch) || isdigit(ch) || ch == '_')
            {
                buffer[count++] = ch;
                ch = fgetc(fptr);
            }
            buffer[count] = '\0';

            // Print only identifiers
            if(!is_keyword(buffer))
            {
                printf("Identifier          : %s\n", buffer);
            }
            continue;
        }

        // Numeric constant handling
        if(isdigit(ch))
        {
            count = 0;
            while(isdigit(ch) || ch == '.' || isalpha(ch))
            {
                buffer[count++] = ch;
                ch = fgetc(fptr);
            }

            buffer[count] = '\0';

            // Validate numeric constant
            if(!check_number(buffer))
            {
                erbuff[ersize++] = "Error: Invalid numeric constant";
            }

            printf("Numeric constant    : %s\n", buffer);
            continue;
        }

        // Operator handling
        if ((ch == '+' || ch == '-' || 
             ch == '>' || ch == '<' || 
             ch == '=' || ch == '!' || 
             ch == '*' || ch == '^' || 
             ch == '%' || ch == '&' ||
             ch == '|' || ch == '/')
            && ch != '\n' && ch != ' ' && ch != EOF)
        {
            count = 0;
            while (ch != ' ' && ch != '\n' && ch != EOF &&
                   (ch == '+' || ch == '-' || ch == '/' ||
                    ch == '>' || ch == '<' ||
                    ch == '=' || ch == '!' ||
                    ch == '*' || ch == '^' || ch == '%' ||
                    ch == '&' || ch == '|'))
            {
                buffer[count++] = ch;
                ch = fgetc(fptr);
            }
            buffer[count] = '\0';

            // Validate multi-character operators
            if(strlen(buffer) > 1)
            {
                int check_op = check_operator(buffer);
                if(check_op == 0)
                {
                    erbuff[ersize++] = "Error: Invalid operator";
                    printf("Error: Invalid operator\n");
                }
            }
            printf("Operator            : %s\n", buffer);
            continue;
        }

        // String and character literal handling
        if (ch == '"' || ch == 39)
        {
            pos = ftell(fptr);

            // Check for proper termination
            n_char = String_termination(ch, fptr);
            if(n_char == 0)
            {
                printf("Error: Missing symbol '\"' or '\''\n");
                return 0;
            }
            fseek(fptr, pos, SEEK_SET);

            count = 0;
            buffer[count++] = ch;
            ch = fgetc(fptr);

            // Read until closing quote
            while ((ch != '"' && ch != 39) && ch != EOF)
            {
                buffer[count++] = ch;
                ch = fgetc(fptr);

                if(ch == EOF)
                {
                    printf("Unterminated quotes\n");
                    return 0;
                }
            }

            buffer[count++] = ch;
            buffer[count] = '\0';

            // Print string or character literal
            if(ch == '"')
                printf("String literal      : %s\n", buffer);
            else
                printf("Character constant  : %s\n", buffer);

            ch = fgetc(fptr);
            continue;
        }

        // Other symbols
        else if (!isalnum(ch) && ch != ' ' && ch != '\n')
        {
            printf("Symbols             : %c\n", ch);
            ch = fgetc(fptr);
            continue;
        }

        // Read next character
        ch = fgetc(fptr);
    }

    // Close file
    fclose(fptr);

    // Print all collected error messages
    for(int i = 0; i < ersize; i++)
    {
        printf("\n%s", erbuff[i]);
    }

    // End of lexer output
    printf("\n==========================================================\n");
}
