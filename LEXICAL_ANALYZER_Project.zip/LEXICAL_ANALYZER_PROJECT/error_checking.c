#include<stdio.h>      // Standard input-output functions
#include"lex.h"        // User-defined header file
#include<string.h>     // String handling functions
#include<ctype.h>      // Character classification functions

/* 
   Array of valid multi-character operators supported
   by this lexical analyser
*/
char operators[16][4] = {
    "++","--","+=","-=","*=","/=","^=","%=",
    "&&","||","<<=",">>=",">=","<=","!=","=="
};

/*
   List of C language keywords
   Used to differentiate keywords from identifiers
*/
KEYWORD kwords[32] = {
    { "auto" }, { "break" }, { "case" }, { "char" },
    { "const" }, { "continue" }, { "default" }, { "do" },
    { "double" }, { "else" }, { "enum" }, { "extern" },
    { "float" }, { "for" }, { "goto" }, { "if" },
    { "int" }, { "long" }, { "register" }, { "return" },
    { "short" }, { "signed" }, { "sizeof" }, { "static" },
    { "struct" }, { "switch" }, { "typedef" }, { "union" },
    { "unsigned" }, { "void" }, { "volatile" }, { "while" }
};

/* 
   is_keyword function Checks whether the given buffer matches
             any C language keyword
*/
int is_keyword(char *buf)
{
    // Iterate through keyword list
    for(int i = 0; i < 32; i++)
    {
        // Compare buffer with keyword
        if(!strcmp(buf, kwords[i].key))
        {
            printf("Keyword             : %s\n", buf);
            return 1;   // Keyword found
        }
    }
    return 0;           // Not a keyword
}

/* 
   String_termination checks whether string/character literals
             are properly terminated
*/
int String_termination(char ch, FILE *fp)
{
    // Continue scanning until EOF
    while(ch != EOF)
    {
        // If starting quote is found
        if (ch == '"' || ch == 39)
        {
            ch = fgetc(fp);

            // Scan characters inside string/char literal
            while ((ch != '"' && ch != 39) && ch != EOF && ch != '\n')
            {
                ch = fgetc(fp);
            }
        }

        // If newline or EOF occurs before closing quote
        if(ch == EOF || ch == '\n')
        {
            return 0;   // Unterminated literal
        }
        else
        {
            return 1;   // Properly terminated
        }
    }
}

/* 
   Checks matching of {}, [], and ()
             Ignores content inside string literals
*/
int check_syntax(char ch, FILE *fp, char *erbuff[], int *ersize)
{
    int count1 = 0;   // Counter for {}
    int count2 = 0;   // Counter for []
    int count3 = 0;   // Counter for ()

    // Scan entire file
    while(ch != EOF)
    {
        // Skip string and character literals
        if (ch == '"' || ch == 39)
        {
            ch = fgetc(fp);
            while ((ch != '"' && ch != 39) && ch != EOF && ch != '\n')
            {
                ch = fgetc(fp);
            }
        }

        // Count opening and closing symbols
        if(ch == '{') ++count1;
        if(ch == '}') --count1;

        if(ch == '[') ++count2;
        if(ch == ']') --count2;

        if(ch == '(') ++count3;
        if(ch == ')') --count3;

        ch = fgetc(fp);
    }

    // Store syntax errors instead of stopping execution
    if(count1 != 0)
        erbuff[(*ersize)++] = "Error: Missing symbol '{' or '}'";

    if(count2 != 0)
        erbuff[(*ersize)++] = "Error: Missing symbol '[' or ']'";

    if(count3 != 0)
        erbuff[(*ersize)++] = "Error: Missing symbol '(' or ')'";

    return 1;
}

/* 
   Validates multi-character operators
*/
int check_operator(char *buffer)
{
    // Compare buffer with known operators
    for(int i = 0; i < 16; i++)
    {
        if(!strcmp(buffer, operators[i]))
        {
            return 1;   // Valid operator
        }
    }
    return 0;           // Invalid operator
}

/* 
   Validates numeric constants
        checks- Integers
             - Floating point numbers
             - Hexadecimal (0x)
             - Binary (ending with b)
             - Octal (leading 0)
*/
int check_number(char *buffer)
{
    int len = strlen(buffer);

    /* ---------- Floating point number ---------- */
    if(strchr(buffer, '.') != NULL)
    {
        int dot_count=0;
        int i = 0;
        while(i < len - 1)
        {
            if(buffer[i]=='.')
            {
                ++dot_count;
            }
            if(isalpha(buffer[i]) || dot_count>1)
                return 0;   // Invalid float
            i++;
        }

        // Last character can be digit or f/F
        if(buffer[len-1] == 'f' || buffer[len-1] == 'F' || isdigit(buffer[len-1]))
            return 1;
    }

    /* ---------- Hexadecimal number ---------- */
    if(buffer[0] == '0' && (buffer[1] == 'x' || buffer[1] == 'X'))
    {
        int i = 2;
        while(i < len)
        {
            if(!((buffer[i] >= 'A' && buffer[i] <= 'F') ||
                 (buffer[i] >= 'a' && buffer[i] <= 'f') ||
                 isdigit(buffer[i])))
            {
                return 0;
            }
            i++;
        }
        return 1;
    }

    /* ---------- Binary number (ending with b) ---------- */
    //if(buffer[len-1] == 'b')
    if(buffer[0] == '0' && buffer[1]=='b')
    {
        int i = 2;
        while(i < len - 1)
        {
            if(!(buffer[i] >= '0' && buffer[i] <= '1'))
                return 0;
            i++;
        }
        return 1;
    }

    /* ---------- Octal number ---------- */
    if(buffer[0] == '0')
    {
        int i = 1;
        while(i < len)
        {
            if(!(buffer[i] >= '0' && buffer[i] <= '7') || isalpha(buffer[i]))
                return 0;
            i++;
        }
    }

    /* ---------- Decimal integer ---------- */
    int i = 0;
    while(i < len)
    {
        if(isalpha(buffer[i]))
            return 0;
        i++;
    }

    return 1;  
}
